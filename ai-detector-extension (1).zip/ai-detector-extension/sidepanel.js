// sidepanel.js

let currentTabId = null;
let allResults = [];
let currentFilter = 'all';
let scanInProgress = false;

// ── Get current tab ──────────────────────────────────────────
async function getCurrentTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

// ── Update status bar ────────────────────────────────────────
function setStatus(type, text) {
  const dot = document.getElementById('statusDot');
  const statusText = document.getElementById('statusText');
  dot.className = 'status-dot dot-' + type;
  statusText.textContent = text;
}

// ── Update summary pills ─────────────────────────────────────
function updateSummary() {
  const done = allResults.filter(r => r.status === 'done');
  const fake = done.filter(r => r.result?.label === 'FAKE').length;
  const real = done.filter(r => r.result?.label === 'REAL').length;
  const pending = allResults.filter(r => r.status === 'pending' || r.status === 'scanning').length;

  document.getElementById('fakeCount').textContent = `${fake} AI`;
  document.getElementById('realCount').textContent = `${real} Real`;
  const pendingEl = document.getElementById('pendingCount');
  if (pending > 0) {
    pendingEl.textContent = `${pending} scanning…`;
    pendingEl.style.display = '';
  } else {
    pendingEl.style.display = 'none';
  }
  document.getElementById('summary').style.display = 'flex';
}

// ── Render image list ────────────────────────────────────────
function renderList() {
  const list = document.getElementById('imageList');

  let filtered = allResults;
  if (currentFilter === 'fake') filtered = allResults.filter(r => r.result?.label === 'FAKE');
  if (currentFilter === 'real') filtered = allResults.filter(r => r.result?.label === 'REAL');

  if (filtered.length === 0 && allResults.length === 0) {
    list.innerHTML = `
      <div class="empty">
        <div class="empty-icon">🔍</div>
        <div class="empty-title">No images found</div>
        <div class="empty-sub">No images larger than 80×80px were found on this page.</div>
      </div>`;
    return;
  }

  list.innerHTML = filtered.map((item, i) => {
    const r = item.result;
    const isScanning = item.status === 'scanning';
    const isDone = item.status === 'done';
    const hasError = r?.error;

    let labelHTML = '';
    let confBarHTML = '';
    let confTextHTML = '';
    let pretrainedHTML = '';

    if (isScanning) {
      labelHTML = `<span class="label-badge label-scanning">Scanning…</span>`;
    } else if (hasError) {
      labelHTML = `<span class="label-badge label-error">Error</span>`;
      confTextHTML = `<div class="conf-text" style="color:#ef4444;font-size:10px">${r.error.slice(0, 60)}</div>`;
    } else if (isDone && r?.label) {
      const isFake = r.label === 'FAKE';
      labelHTML = `<span class="label-badge ${isFake ? 'label-fake' : 'label-real'}">${isFake ? '⚠ AI-Generated' : '✓ Real'}</span>`;
      const pct = r.confidence ?? 50;
      confBarHTML = `
        <div class="conf-bar-wrap">
          <div class="conf-bar ${isFake ? 'bar-fake' : 'bar-real'}" style="width:${pct}%"></div>
        </div>`;
      confTextHTML = `<div class="conf-text">CNN confidence: ${pct.toFixed(1)}%</div>`;
      if (r.pretrainedLabel) {
        pretrainedHTML = `<div class="pretrained-text">Pretrained: ${r.pretrainedLabel}${r.pretrainedConf ? ` (${r.pretrainedConf.toFixed(1)}%)` : ''}</div>`;
      }
    } else {
      labelHTML = `<span class="label-badge label-error">Pending</span>`;
    }

    const shortSrc = item.src.length > 50 ? item.src.slice(0, 47) + '…' : item.src;

    return `
      <div class="image-card" data-src="${encodeURIComponent(item.src)}" data-label="${r?.label || ''}" data-index="${i}">
        <div class="thumb-wrap">
          <img src="${item.src}" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'" alt="">
          <div class="thumb-placeholder" style="display:none">🖼</div>
        </div>
        <div class="card-info">
          <div class="card-label">${labelHTML}</div>
          ${confBarHTML}
          ${confTextHTML}
          ${pretrainedHTML}
          <div class="img-src">${shortSrc}</div>
        </div>
      </div>`;
  }).join('');

  // Click to highlight individual image
  list.querySelectorAll('.image-card').forEach(card => {
    card.addEventListener('click', () => {
      const src = decodeURIComponent(card.dataset.src);
      const label = card.dataset.label;
      if (label && currentTabId) {
        chrome.runtime.sendMessage({ type: 'HIGHLIGHT', tabId: currentTabId, src, label });
      }
    });
  });
}

// ── Scan button ──────────────────────────────────────────────
document.getElementById('scanBtn').addEventListener('click', async () => {
  if (scanInProgress) return;
  const tab = await getCurrentTab();
  currentTabId = tab.id;
  allResults = [];
  scanInProgress = true;

  setStatus('scanning', 'Scanning page for images…');
  document.getElementById('summary').style.display = 'none';
  document.getElementById('filterTabs').style.display = 'none';
  document.getElementById('highlightBtn').style.display = 'none';
  document.getElementById('clearBtn').style.display = 'none';
  document.getElementById('imageList').innerHTML = `
    <div class="empty">
      <div class="empty-icon" style="animation: pulse 1s infinite">🔍</div>
      <div class="empty-title">Scanning…</div>
      <div class="empty-sub">Finding images on the page and sending them to the detector.</div>
    </div>`;

  chrome.tabs.sendMessage(tab.id, { type: 'SCAN_REQUEST' });
});

// ── Highlight all button ─────────────────────────────────────
document.getElementById('highlightBtn').addEventListener('click', () => {
  if (currentTabId) {
    chrome.runtime.sendMessage({ type: 'HIGHLIGHT_ALL', tabId: currentTabId });
  }
});

// ── Clear button ─────────────────────────────────────────────
document.getElementById('clearBtn').addEventListener('click', () => {
  allResults = [];
  scanInProgress = false;
  setStatus('idle', 'Click scan to analyze images on this page');
  document.getElementById('summary').style.display = 'none';
  document.getElementById('filterTabs').style.display = 'none';
  document.getElementById('highlightBtn').style.display = 'none';
  document.getElementById('clearBtn').style.display = 'none';
  document.getElementById('imageList').innerHTML = `
    <div class="empty">
      <div class="empty-icon">🖼</div>
      <div class="empty-title">No scan yet</div>
      <div class="empty-sub">Press <strong>Scan Page</strong> to detect AI-generated images.</div>
    </div>`;
});

// ── Filter tabs ──────────────────────────────────────────────
document.querySelectorAll('.filter-tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.filter-tab').forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    currentFilter = tab.dataset.filter;
    renderList();
  });
});

// ── Listen for messages from background ─────────────────────
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.tabId && msg.tabId !== currentTabId) return;

  if (msg.type === 'SCAN_STARTED') {
    setStatus('scanning', `Found ${msg.count} image${msg.count !== 1 ? 's' : ''} — analyzing…`);
    allResults = Array(msg.count).fill(null).map((_, i) => ({
      src: '', status: 'pending', result: null
    }));
  }

  if (msg.type === 'IMAGE_SCANNING') {
    if (allResults[msg.index]) {
      allResults[msg.index].src = msg.src;
      allResults[msg.index].status = 'scanning';
    }
    const done = allResults.filter(r => r.status === 'done').length;
    setStatus('scanning', `Analyzing image ${done + 1} of ${allResults.length}…`);
    updateSummary();
    renderList();
  }

  if (msg.type === 'IMAGE_RESULT') {
    if (allResults[msg.index]) {
      allResults[msg.index].src = msg.src;
      allResults[msg.index].status = 'done';
      allResults[msg.index].result = msg.result;
    }
    updateSummary();
    renderList();
  }

  if (msg.type === 'SCAN_COMPLETE') {
    scanInProgress = false;
    const fake = allResults.filter(r => r.result?.label === 'FAKE').length;
    const total = allResults.filter(r => r.status === 'done').length;
    setStatus('done', `Done — ${fake} of ${total} images flagged as AI-generated`);
    document.getElementById('filterTabs').style.display = 'flex';
    document.getElementById('highlightBtn').style.display = '';
    document.getElementById('clearBtn').style.display = '';
    updateSummary();
    renderList();
  }
});
