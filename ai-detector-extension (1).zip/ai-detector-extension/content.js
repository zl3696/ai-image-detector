// content.js — scans the page for images and sends them to the background worker

const MIN_SIZE = 80; // ignore tiny icons/spacers

function getPageImages() {
  const imgs = Array.from(document.querySelectorAll('img'));
  return imgs
    .filter(img => {
      const rect = img.getBoundingClientRect();
      return (
        img.src &&
        img.src.startsWith('http') &&
        rect.width >= MIN_SIZE &&
        rect.height >= MIN_SIZE
      );
    })
    .map(img => ({
      src: img.src,
      width: Math.round(img.naturalWidth || img.width),
      height: Math.round(img.naturalHeight || img.height),
      alt: img.alt || '',
      x: Math.round(img.getBoundingClientRect().left + window.scrollX),
      y: Math.round(img.getBoundingClientRect().top + window.scrollY),
    }))
    .slice(0, 20); // cap at 20 images per page
}

function highlightImage(src, label) {
  const imgs = Array.from(document.querySelectorAll('img'));
  const target = imgs.find(img => img.src === src);
  if (!target) return;

  // Remove any existing badge on this image
  const existingBadge = target.parentElement.querySelector('.aidet-badge');
  if (existingBadge) existingBadge.remove();

  // Make parent relative if needed
  const parent = target.parentElement;
  const parentPos = getComputedStyle(parent).position;
  if (parentPos === 'static') parent.style.position = 'relative';

  // Create badge
  const badge = document.createElement('div');
  badge.className = 'aidet-badge';
  const isFake = label === 'FAKE';
  badge.style.cssText = `
    position: absolute;
    top: 6px;
    left: 6px;
    z-index: 9999;
    padding: 3px 8px;
    border-radius: 4px;
    font-size: 11px;
    font-weight: 700;
    font-family: system-ui, sans-serif;
    letter-spacing: 0.5px;
    pointer-events: none;
    background: ${isFake ? 'rgba(220,38,38,0.92)' : 'rgba(22,163,74,0.92)'};
    color: white;
    box-shadow: 0 1px 4px rgba(0,0,0,0.4);
  `;
  badge.textContent = isFake ? '⚠ AI' : '✓ REAL';
  parent.appendChild(badge);
}

// Listen for highlight requests from the side panel (via background)
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'HIGHLIGHT_IMAGE') {
    highlightImage(msg.src, msg.label);
  }
  if (msg.type === 'SCAN_REQUEST') {
    const images = getPageImages();
    chrome.runtime.sendMessage({ type: 'IMAGES_FOUND', images });
  }
});

// Auto-scan on load and notify background
const images = getPageImages();
if (images.length > 0) {
  chrome.runtime.sendMessage({ type: 'IMAGES_FOUND', images });
}
