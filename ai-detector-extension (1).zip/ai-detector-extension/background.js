// background.js — service worker
// Receives images from content script, calls HuggingFace Gradio API, returns results

const HF_SPACE = "https://emilyl613-ai-image-detector.hf.space";

// Open side panel when extension icon is clicked
chrome.action.onClicked.addListener((tab) => {
  chrome.sidePanel.open({ tabId: tab.id });
  chrome.tabs.sendMessage(tab.id, { type: 'SCAN_REQUEST' });
});

// ── Call the Gradio API (modern two-step SSE pattern) ────────
//
// Modern Gradio API flow:
//   1. POST /gradio_api/call/<fn_name>  → returns { event_id }
//   2. GET  /gradio_api/call/<fn_name>/<event_id>  → SSE stream, read until "complete"
//
// Your detect_image fn in app.py is exposed as "/detect_image" by Gradio
// (Gradio auto-names routes from the function name when using gr.Blocks + .click())
// We upload the image as a blob via /gradio_api/upload first, then pass the
// returned file path as the image input.

async function callHuggingFace(imageUrl) {
  try {
    // Step 1: Fetch the image
    const imgResponse = await fetch(imageUrl);
    if (!imgResponse.ok) throw new Error(`Could not fetch image (${imgResponse.status})`);
    const blob = await imgResponse.blob();
    const mimeType = blob.type || 'image/jpeg';

    // Step 2: Upload image to Gradio's upload endpoint
    const formData = new FormData();
    formData.append('files', blob, 'image.jpg');
    const uploadResp = await fetch(`${HF_SPACE}/gradio_api/upload`, {
      method: 'POST',
      body: formData
    });
    if (!uploadResp.ok) {
      const t = await uploadResp.text();
      throw new Error(`Upload failed (${uploadResp.status}): ${t.slice(0, 150)}`);
    }
    const uploadedPaths = await uploadResp.json(); // array of file paths e.g. ["/tmp/gradio/abc.jpg"]
    const uploadedPath = uploadedPaths[0];

    // Step 3: Call predict — POST to start the job
    const predictResp = await fetch(`${HF_SPACE}/gradio_api/call/detect_image`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        data: [{ path: uploadedPath, mime_type: mimeType }]
      })
    });
    if (!predictResp.ok) {
      const t = await predictResp.text();
      throw new Error(`Predict call failed (${predictResp.status}): ${t.slice(0, 150)}`);
    }
    const { event_id } = await predictResp.json();

    // Step 4: Poll the SSE stream for the result
    const resultData = await readGradioSSE(
      `${HF_SPACE}/gradio_api/call/detect_image/${event_id}`
    );

    // resultData = [our_result_markdown, pretrained_markdown, gradcam_image_obj]
    const ourResult      = resultData[0] || '';
    const pretrainedResult = resultData[1] || '';

    // Parse our CNN result: "**FAKE (AI-Generated)**\nConfidence: 87.3%"
    const isFake    = ourResult.includes('FAKE');
    const confMatch = ourResult.match(/(\d+\.?\d*)%/);
    const confidence = confMatch ? parseFloat(confMatch[1]) : null;

    // Parse pretrained result
    const pretrainedLower = pretrainedResult.toLowerCase();
    const pretrainedLabel = (pretrainedLower.includes('artificial') || pretrainedLower.includes('fake'))
      ? 'AI' : 'REAL';
    const pretrainedConfMatch = pretrainedResult.match(/(\d+\.?\d*)%/);
    const pretrainedConf = pretrainedConfMatch ? parseFloat(pretrainedConfMatch[1]) : null;

    return {
      label: isFake ? 'FAKE' : 'REAL',
      confidence,
      pretrainedLabel,
      pretrainedConf,
      ourRaw: ourResult,
      pretrainedRaw: pretrainedResult,
      error: null
    };

  } catch (err) {
    return { label: null, confidence: null, error: err.message };
  }
}

// Reads a Gradio SSE stream and resolves with the data array from the "complete" event
function readGradioSSE(url) {
  return new Promise(async (resolve, reject) => {
    try {
      const resp = await fetch(url);
      if (!resp.ok) {
        const t = await resp.text();
        return reject(new Error(`SSE fetch failed (${resp.status}): ${t.slice(0, 150)}`));
      }
      const reader = resp.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop(); // keep incomplete last line

        let eventType = null;
        for (const line of lines) {
          if (line.startsWith('event: ')) {
            eventType = line.slice(7).trim();
          } else if (line.startsWith('data: ')) {
            const dataStr = line.slice(6).trim();
            if (eventType === 'complete') {
              try {
                const parsed = JSON.parse(dataStr);
                return resolve(parsed); // array of outputs
              } catch {
                return reject(new Error('Could not parse SSE complete data'));
              }
            }
            if (eventType === 'error') {
              return reject(new Error(`Gradio error: ${dataStr}`));
            }
          }
        }
      }
      reject(new Error('SSE stream ended without a complete event'));
    } catch (err) {
      reject(err);
    }
  });
}

// ── Message handling ─────────────────────────────────────────
let pendingImages = {};      // tabId -> [{src, width, height, ...}]
let scanResults = {};        // tabId -> [{...imageInfo, result}]

chrome.runtime.onMessage.addListener((msg, sender) => {
  const tabId = sender.tab?.id;

  if (msg.type === 'IMAGES_FOUND') {
    pendingImages[tabId] = msg.images;
    scanResults[tabId] = msg.images.map(img => ({ ...img, status: 'pending', result: null }));
    // Notify side panel that images were found
    chrome.runtime.sendMessage({
      type: 'SCAN_STARTED',
      tabId,
      count: msg.images.length
    }).catch(() => {});
    // Start scanning
    runScan(tabId, msg.images);
  }

  if (msg.type === 'GET_RESULTS') {
    return; // handled via sendMessage below
  }

  if (msg.type === 'REQUEST_RESULTS') {
    chrome.runtime.sendMessage({
      type: 'CURRENT_RESULTS',
      results: scanResults[msg.tabId] || []
    }).catch(() => {});
  }

  if (msg.type === 'HIGHLIGHT') {
    chrome.tabs.sendMessage(msg.tabId, {
      type: 'HIGHLIGHT_IMAGE',
      src: msg.src,
      label: msg.label
    });
  }

  if (msg.type === 'HIGHLIGHT_ALL') {
    const results = scanResults[msg.tabId] || [];
    results.forEach(r => {
      if (r.result?.label) {
        chrome.tabs.sendMessage(msg.tabId, {
          type: 'HIGHLIGHT_IMAGE',
          src: r.src,
          label: r.result.label
        });
      }
    });
  }
});

async function runScan(tabId, images) {
  for (let i = 0; i < images.length; i++) {
    const img = images[i];
    scanResults[tabId][i].status = 'scanning';

    // Notify side panel of progress
    chrome.runtime.sendMessage({
      type: 'IMAGE_SCANNING',
      tabId,
      index: i,
      src: img.src
    }).catch(() => {});

    const result = await callHuggingFace(img.src);
    scanResults[tabId][i].status = 'done';
    scanResults[tabId][i].result = result;

    // Notify side panel of this result
    chrome.runtime.sendMessage({
      type: 'IMAGE_RESULT',
      tabId,
      index: i,
      src: img.src,
      result
    }).catch(() => {});
  }

  chrome.runtime.sendMessage({
    type: 'SCAN_COMPLETE',
    tabId,
    results: scanResults[tabId]
  }).catch(() => {});
}
